#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14159265
#define PLANET_COUNT 8

const char* planetNames[] = {"Merkur", "Venus", "Dunya", "Mars", "Jupiter", "Saturn", "Uranus", "Neptun"};

void serbestDusme(double *g, double t);
void yukariAtis(double *g, double v0);
void agirlikDeneyi(double *g, double m);
void potansiyelEnerji(double *g, double m, double h);
void hidrostatikBasinc(double *g, double rho, double h);
void arsimetKuvveti(double *g, double rho, double V);
void basitSarkac(double *g, double L);
void ipGerilmesi(double *g, double m);
void asansorDeneyi(double *g, double m, double a, int yon);

int main() {
    double g_values[PLANET_COUNT] = {3.70, 8.87, 9.81, 3.71, 24.79, 10.44, 8.69, 11.15};
    char bilimInsani[100];
    int secim = 0;
    printf("Bilim insaninin adini giriniz: ");
    scanf(" %[^\n]s", bilimInsani);

    while (secim != -1) {
        printf("\n--- SAYIN %s, DENEY MENUSU ---\n", bilimInsani);
        printf("1. Serbest Dusme\n2. Yukari Atis\n3. Agirlik\n4. Potansiyel Enerji\n5. Hidrostatik Basinc\n");
        printf("6. Arsimet Kaldirma Kuvveti\n7. Basit Sarkac Periyodu\n8. Sabit Ip Gerilmesi\n9. Asansor Deneyi\n-1. Cikis\n");
        printf("Seciminiz: ");
        scanf("%d", &secim);

        if (secim == -1) break;

        double m, h, t, v0, rho, V, L, a;
        int yon;

        switch (secim) {
            case 1:
                printf("Sure (t) s: "); scanf("%lf", &t);
                t = (t < 0) ? -t : t;
                serbestDusme(g_values, t);
                break;
            case 2:
                printf("Hiz (v0) m/s: "); scanf("%lf", &v0);
                v0 = (v0 < 0) ? -v0 : v0;
                yukariAtis(g_values, v0);
                break;
            case 3:
                printf("Kutle (m) kg: "); scanf("%lf", &m);
                m = (m < 0) ? -m : m;
                agirlikDeneyi(g_values, m);
                break;
            case 4:
                printf("Kutle (m) kg ve Yukseklik (h) m: "); scanf("%lf %lf", &m, &h);
                m = (m < 0) ? -m : m; h = (h < 0) ? -h : h;
                potansiyelEnerji(g_values, m, h);
                break;
            case 5:
                printf("Ozkutle (rho) kg/m3 ve Derinlik (h) m: "); scanf("%lf %lf", &rho, &h);
                rho = (rho < 0) ? -rho : rho; h = (h < 0) ? -h : h;
                hidrostatikBasinc(g_values, rho, h);
                break;
            case 6:
                printf("Sivi Ozkutlesi (rho) ve Batan Hacim (V) m3: "); scanf("%lf %lf", &rho, &V);
                rho = (rho < 0) ? -rho : rho; V = (V < 0) ? -V : V;
                arsimetKuvveti(g_values, rho, V);
                break;
            case 7:
                printf("Ip uzunlugu (L) m: "); scanf("%lf", &L);
                L = (L < 0) ? -L : L;
                basitSarkac(g_values, L);
                break;
            case 8:
                printf("Kutle (m) kg: "); scanf("%lf", &m);
                m = (m < 0) ? -m : m;
                ipGerilmesi(g_values, m);
                break;
            case 9:
                printf("Kutle (m) kg ve Asansor Ivmesi (a) m/s2: "); scanf("%lf %lf", &m, &a);
                printf("Yonu Secin (1: Yukari Hizlanan/Asagi Yavaslayan, 2: Asagi Hizlanan/Yukari Yavaslayan): ");
                scanf("%d", &yon);
                m = (m < 0) ? -m : m; a = (a < 0) ? -a : a;
                asansorDeneyi(g_values, m, a, yon);
                break;
            default:
                printf("Gecersiz secim!\n");
        }
    }
    return 0;
}

void serbestDusme(double *g, double t) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f m\n", planetNames[i], 0.5 * (*(g + i)) * t * t);
}
void yukariAtis(double *g, double v0) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f m\n", planetNames[i], (v0 * v0) / (2 * (*(g + i))));
}
void agirlikDeneyi(double *g, double m) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f Newton\n", planetNames[i], m * (*(g + i)));
}
void potansiyelEnerji(double *g, double m, double h) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f Joule\n", planetNames[i], m * (*(g + i)) * h);
}
void hidrostatikBasinc(double *g, double rho, double h) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f Pascal\n", planetNames[i], rho * (*(g + i)) * h);
}
void arsimetKuvveti(double *g, double rho, double V) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f Newton\n", planetNames[i], rho * (*(g + i)) * V);
}
void basitSarkac(double *g, double L) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f saniye\n", planetNames[i], 2 * PI * sqrt(L / (*(g + i))));
}
void ipGerilmesi(double *g, double m) {
    for (int i = 0; i < PLANET_COUNT; i++)
        printf("%s: %.2f Newton\n", planetNames[i], m * (*(g + i)));
}
void asansorDeneyi(double *g, double m, double a, int yon) {
    for (int i = 0; i < PLANET_COUNT; i++) {
        double N = (yon == 1) ? m * ((*(g + i)) + a) : m * ((*(g + i)) - a); //
        printf("%s: %.2f Newton\n", planetNames[i], N);
    }
}
